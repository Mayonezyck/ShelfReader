/* Copyright (c) 2019 Adam Jakubek, Rafał Gałczyński
 * Released under the MIT license (see attached LICENSE file).
 */

#ifndef FLAGS_H
#define FLAGS_H

#define LLIST_HAS_PY_NONE_REF (0x01)

#endif /* FLAGS_H */
